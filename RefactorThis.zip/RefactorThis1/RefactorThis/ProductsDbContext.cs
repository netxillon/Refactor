﻿using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using RefactorThis.Models;

namespace RefactorThis
{
    public class ProductsDbContext : DbContext
    {
        private readonly DbContextOptions<ProductsDbContext> _dbContext;
        public ProductsDbContext(DbContextOptions<ProductsDbContext> dbContext) : base(dbContext)
        {

        }

        public DbSet<Models.Product> products { get; set; }
        public DbSet<Models.ProductOption> ProductOptions { get; set; }

    }
}