﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RefactorThis;
using RefactorThis.Models;

namespace RefactorThis.Controllers
{
    [Route("Products")]
    [ApiController]
    public class ProductOptionsController : Controller
    {
        private readonly ProductsDbContext _context;

        public ProductOptionsController(ProductsDbContext context)
        {
            _context = context;
        }

        // GET: ProductOptions
        [HttpGet("ProductOptions")]
        public async Task<IActionResult> Index()
        {
            return View(await _context.ProductOptions.ToListAsync());
        }

        // GET: Products/{Product_id}/Options
        [HttpGet("{Product_id}/Options")]
        public async Task<IActionResult> getOptionsbyProductID(Guid? Product_id)
        {
            if (Product_id == null)
            {
                return NotFound();
            }

            var productOption = await _context.ProductOptions
                .FirstOrDefaultAsync(m => m.ProductId == Product_id);
            if (productOption == null)
            {
                return NotFound();
            }

            return View(productOption);
        }


        // GET /products/{id}/options/{optionId}
        [HttpGet("{Product_id}/Options/{ProductOptions_id}")]
        public async Task<IActionResult> Details(Guid? Product_id, Guid? ProductOptions_id)
        {
            if (Product_id == null)
            {
                return NotFound();
            }

            var productOption = await _context.ProductOptions
                .FirstOrDefaultAsync(m => m.ProductId == Product_id && m.Id == ProductOptions_id);
            if (productOption == null)
            {
                return NotFound();
            }

            return View(productOption);
        }

        // GET: ProductOptions/Create
        public IActionResult Create()
        {
            return View();
        }


        //POST /products/{id}/options` 
        [HttpPost("{product_id}/Options")]
        public async Task<IActionResult> Create([FromRoute]Guid? product_id, [FromBody] ProductOption productOption)
        {
            if (product_id == null)
            {
                return NotFound();
            }

            var product = await _context.products.FindAsync(product_id);

            if (product == null)
                return NotFound();

            if (ModelState.IsValid)
            {
                productOption.Id = Guid.NewGuid();
                _context.Add(productOption);
                product.productOptions.Add(productOption);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(productOption);
        }

        // GET: ProductOptions/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var productOption = await _context.ProductOptions.FindAsync(id);
            if (productOption == null)
            {
                return NotFound();
            }
            return View(productOption);
        }

        // PUT /products/{id}/options/{optionId}` 
        [HttpPut("{product_id}/Options")]
        public async Task<IActionResult> Edit([FromRoute]Guid product_id, [FromBody] ProductOption productOption)
        {
            if (product_id != productOption.ProductId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(productOption);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductOptionExists(productOption.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(productOption);
        }


        //DELETE /products/{id}/options/{optionId}
        [HttpPost("{product_id}/Options/{productoption_Id}")]
        public async Task<IActionResult> Delete([FromRoute]Guid? product_id, [FromRoute]Guid productoption_Id)
        {
            var productOption = await _context.ProductOptions.FindAsync(productoption_Id);
            _context.ProductOptions.Remove(productOption);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProductOptionExists(Guid id)
        {
            return _context.ProductOptions.Any(e => e.Id == id);
        }
    }
}
